package Junit.mock.mockito.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import Junit.mock.mockito.service.StudentService;
import Junit.mock.model.StudentModel;

@SpringBootTest
public class StudentRepositoryTest_Mock {

	
	@Mock
	StudentRepository repo;
	
	@Autowired
	StudentModel stu;
	
//	@InjectMocks // auto inject StudentRepository
//    private StudentService stuService = new StudentService();

    @BeforeEach
    void setMockOutput() {
        when(repo.save(stu)).thenReturn(stu);
    }

    @DisplayName("Test for save Student details using Mockito")
    @Test
    void testGet() {
        assertEquals(stu, repo.save(stu));
    }
	
	
}
