package com.techprimers.kafka.springbootkafkaproducerexample.config;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.techprimers.kafka.springbootkafkaproducerexample.model.User;

@Service
public class KafkaConsumerListener {

	@KafkaListener(topics="Kafka_ExampleNew", group = "group_id" )
	public void consume(String message) {
		System.out.println("Consumed message =-------" +message);
	}
	
	//************************************************************
	
	@KafkaListener(topics="Kafka_ExampleUser", group = "group_id_user", containerFactory = "kafkaListenerContainerFactoryUser" )
	public void consumeUser(User user) {
		System.out.println("Consumed message =-------" +user);
	}
}
