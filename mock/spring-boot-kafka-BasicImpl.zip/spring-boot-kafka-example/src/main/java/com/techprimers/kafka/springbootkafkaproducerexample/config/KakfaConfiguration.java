package com.techprimers.kafka.springbootkafkaproducerexample.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.techprimers.kafka.springbootkafkaproducerexample.model.User;


@EnableKafka
@Configuration
public class KakfaConfiguration {


	/* *************************  Producer Configuration *************************************** */

	/*
	 * @Bean public ProducerFactory<String, User> producerFactory() { Map<String,
	 * Object> config = new HashMap<>();
	 * 
	 * config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
	 * config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class)
	 * ;
	 * config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,JsonSerializer.class)
	 * ;
	 * 
	 * return new DefaultKafkaProducerFactory<>(config);
	 * 
	 * 
	 * @Bean public KafkaTemplate<String, User> kafkaTemplate() { return new
	 * KafkaTemplate<>(producerFactory()); } }
	 */


	/* *************************  Consumer Configuration *************************************** */
	@Bean public ConsumerFactory<String, String> consumerFactory() { 
		Map<String,Object> config = new HashMap<>();

		config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
		config.put(ConsumerConfig.GROUP_ID_CONFIG,"group_id");
		config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
		config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
		return new DefaultKafkaConsumerFactory<>(config); 
	}

	@Bean public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
		ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory());
		return factory;
	}


	//*****************************************************************************************************
	@Bean public ConsumerFactory<String, User> consumerFactoryUser() { 
		Map<String,Object> config = new HashMap<>();

		config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
		config.put(ConsumerConfig.GROUP_ID_CONFIG,"group_id_user");
		config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class);
		config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,JsonDeserializer.class);
		return new DefaultKafkaConsumerFactory<>(config, new StringDeserializer(), new JsonDeserializer<>(User.class)); 
	}

	@Bean public ConcurrentKafkaListenerContainerFactory<String, User> kafkaListenerContainerFactoryUser() {
		ConcurrentKafkaListenerContainerFactory<String, User> factory= new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactoryUser());
		return factory;
	}


}
